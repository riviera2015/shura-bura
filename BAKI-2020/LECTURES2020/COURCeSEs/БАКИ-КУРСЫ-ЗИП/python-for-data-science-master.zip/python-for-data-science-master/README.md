# Python-for-Data-Science
Осторожное введение в науку о данных / A Gentle Intro to Data Science
