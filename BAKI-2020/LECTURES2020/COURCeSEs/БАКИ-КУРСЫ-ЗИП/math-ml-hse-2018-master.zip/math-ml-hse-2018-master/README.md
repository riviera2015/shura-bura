# math-ml-hse-2018

* [Конспекты лекций](http://math-info.hse.ru/math-ml/chapter/label/chap:2:prob/)
* [Страница курса](http://wiki.cs.hse.ru/Машинное_обучение_на_матфаке_2018/2019)
* [Чат курса в телеграм](https://t-do.ru/joinchat/CDE3khHyzKP1U701FQtszQ)
