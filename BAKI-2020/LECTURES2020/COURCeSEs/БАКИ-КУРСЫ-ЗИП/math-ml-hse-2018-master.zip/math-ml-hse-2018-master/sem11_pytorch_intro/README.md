[Ссылка на Colab](https://colab.research.google.com/drive/1SYSqkoRchfQW8QDc3LW8wBaNzDG6dO99)
