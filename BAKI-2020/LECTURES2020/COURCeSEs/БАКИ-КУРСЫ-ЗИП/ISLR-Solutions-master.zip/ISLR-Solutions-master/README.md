# ISLR-Solutions
The repo contains labs and exercise solutions from ISLR book. The lab code is based on the codes provided in the book 'An Introduction to Statistical Learning' [(link here)](http://www-bcf.usc.edu/~gareth/ISL/). Codes in the exercises are developed by me as part of the 'Data Mining' course at KU Leuven.
