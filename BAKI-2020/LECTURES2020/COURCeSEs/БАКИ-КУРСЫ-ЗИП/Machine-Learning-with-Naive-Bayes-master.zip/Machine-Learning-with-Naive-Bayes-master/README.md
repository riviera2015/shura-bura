# Machine Learning with Naive Bayes
In the mini-project, I'll go through the basics of text analysis using a subset of movie reviews from the rotten tomatoes database. I'll also use a fundamental technique in Bayesian inference, called Naive Bayes. This mini-project is based on Lab 10 of Harvard's CS109 class.
