# -Minimization-of-Churn-Rate-by-Analysis-of-Financial-Habits
         Developed an Machine learning model with Random Forest classifier after feature selection and hyper parameter tuning the          model accuracy was 79.83% based on the financial habits of the customers in the Bank Database. 
